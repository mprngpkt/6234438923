package lab10_2;

public interface Electric {
    
    double HIGH_VOLTAGE = 600;
    double LOW_VOLTAGE = 480;
    
    double getVoltage();
    
}
