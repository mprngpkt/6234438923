package lab10_2;

import java.util.ArrayList;

public class BusTester {

    public static void main(String[] args) {
        
        ArrayList<Bus> arr = new ArrayList<Bus>();
        Hybrid hb = new Hybrid(150,1,600,45,1.2E6);
        CNGBus cb = new CNGBus(200,2,50,1.0E6);
        arr.add(hb);
        arr.add(cb);
        
        for(int i=0; i<arr.size(); i++){
            if(arr.get(i) instanceof Hybrid){
                System.out.println("ID : "+ arr.get(i).getID() + "\n" + "Emission Tier : "+ ((Hybrid)arr.get(i)).getEmissionTier());
                System.out.println("Accel : " + arr.get(i).getAccel());
            }
            if(arr.get(i) instanceof CNGBus){
                System.out.println("ID : "+ arr.get(i).getID() + "\n" + "Emission Tier : "+ ((CNGBus)arr.get(i)).getEmissionTier());
                System.out.println("Accel : " + arr.get(i).getAccel());
            }
        }
    }    
}