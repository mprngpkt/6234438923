/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

/**
 *
 * @author Surasak Prokati
 */
public class LineTester {
    public static void main(String[] args) {
//        Line l1 = new Line(-2,1,1,-2);
//        Line l2 = new Line(-6,-2,-2,0);
        Line l1 = new Line(0,2);
        Line l2 = new Line(2,1);
//        Line l1 = new Line(0.44,3.4);
//        Line l2 = new Line(32,32,9);
//        Line l1 = new Line(3,5);
//        Line l2 = new Line(5);
//        Line l1 = new Line(0,4);
//        Line l2 = new Line(5);
//        Line l1 = new Line(0.44,3.4);
//        Line l2 = new Line(0.44,5);
//        Line l1 = new Line(1,-24);
//        Line l2 = new Line(29,5,53,29);
        
        System.out.println("Are the two lines equals?: "+l1.equals(12));
        System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
        System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
        
        if (l1.getIntersectionPoint(l2).getX()!= Double.NaN && l1.getIntersectionPoint(l2).getX()!=Double.POSITIVE_INFINITY){
            System.out.printf("Point of intersection: "+"%.2f",l1.getIntersectionPoint(l2).getX());
            System.out.printf(","+"%.2f\n",l1.getIntersectionPoint(l2).getY());
    }
    }
}
