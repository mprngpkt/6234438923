/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

import java.awt.geom.Point2D;

/**
 *
 * @author Surasak Prokati
 */
public class Line {

    private final double x;
    private final double m;
    private final double b;
    private final boolean isVerticalLine;

    public Line(double x, double y, double m) {
        this.m = m;
        double bLocal = (y - m*x);
        this.b = bLocal;
        this.x = Double.NaN;
        this.isVerticalLine = false;
    }
    public Line(double x1, double y1, double x2, double y2) {
        double mLocal = (y2-y1)/(x2-x1);
        this.m = mLocal;
        double bLocal = (y1 - mLocal*x1);
        this.b = bLocal;
        this.x = Double.NaN;
        this.isVerticalLine = false;
    }
    public Line(double m, double b) {
        this.m = m;
        this.b = b;
        this.x = Double.NaN;
        this.isVerticalLine = false;
    }
    public Line(double a) {
        this.m = Double.NaN;
        this.b = Double.NaN;
        this.x = a;
        this.isVerticalLine = true;
    }
    public boolean isParallel(Line line) {
        return this.m==line.m;
    }
    public boolean equals(Line line) {
        return (this.m==line.m && this.b==line.b);
    }
    public boolean isIntersect(Line line) {
        boolean isIntersect = false;
        if (!(this.m==line.m)) {
            isIntersect = true;
        }
        return isIntersect;
    }
    
    public Point2D.Double getIntersectionPoint(Line line) {    
        Point2D.Double point = new Point2D.Double();
        if (!this.isVerticalLine && !line.isVerticalLine) {
            double b1 = this.b;
            double b2 = line.b;
            double m1 = this.m;
            double m2 = line.m;
            double xLocal = (b2-b1)/(m1-m2);
            double y = m1*xLocal+b1;
            point.setLocation(xLocal,y);
        }
        else if (!this.isVerticalLine && line.isVerticalLine) {
            double b = this.b;
            double m = this.m;
            double x = line.x;
            double y = m*x+b;
            point.setLocation(x,y);
        }
        else if (this.isVerticalLine && !line.isVerticalLine) {
            double b = line.b;
            double m = line.m;
            double x = this.x;
            double y = m*x+b;
            point.setLocation(x,y);
        }
        else {
            point.setLocation(Double.NaN,Double.NaN);
        }
        return point;
    }
    
}
