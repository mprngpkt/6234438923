package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue{

    private ArrayList<Object> playlist = new ArrayList<Object>();
    
    public MusicBox(){
        
    }
    
    @Override
    public void enqueue(Object o){
        playlist.add(o);
        System.out.println((String)o+" is added in queue.");
    }
    
    
    @Override
    public void dequeue(){
        System.out.println("Now playing "+playlist.get(0));
        playlist.remove(0);
    }
    
}
