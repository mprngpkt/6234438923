package lab8_2;

public class NumericQuestion extends Question{
    
    public NumericQuestion(String question){
        super(question);
    }
    @Override
    public boolean checkAnswer(String response){
        double checking = Double.parseDouble(response) - Double.parseDouble(super.getAnswer());
        boolean check = Math.abs(checking)<=0.01;
        return check;
    }
    
}