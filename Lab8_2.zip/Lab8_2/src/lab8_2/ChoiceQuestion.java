package lab8_2;

import java.util.ArrayList;

public class ChoiceQuestion extends Question{
    private ArrayList<String> choices = new ArrayList<String>();
    
    public ChoiceQuestion(String question){
        super(question);
    }
    public void addChoice(String choice, boolean correct){
        choices.add(choice);
        if (correct==true){
            super.setAnswer(choice);
        }
    }

    @Override
    public void display(){
        super.display();
        for (int i=0; i < choices.size(); i++){
            System.out.println((i+1)+": "+choices.get(i));
        }
    }
    public boolean checkAnswer(String response){
        boolean checking = choices.get(Integer.parseInt(response)-1).equals(super.getAnswer());
        return checking;
    }
    
}
