/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author usci
 */
public class TimeInterval {
    private int start;
    private int end;
    private int startminutes;
    private int endminutes;
    private int minutes;
    public TimeInterval(int start, int end){
        startminutes=start/100*60+start%60;
        endminutes=end/100*60+end%60;
        minutes=startminutes-endminutes;
    }
    public double getHours(){
        return (minutes/60);
    }
    public double getMinutes(){
        return (minutes%60*60);
    }
    
    
}
