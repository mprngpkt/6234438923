/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

/**
 *
 * @author Surasak Prokati
 */
public class Zeller {
    private int dayOfMonth;
    private int month;
    private int year;
    
    public Zeller(int year, int month,int dayOfMonth){
        this.dayOfMonth = dayOfMonth;
        switch(month){
            case 1: this.month = 13; this.year = year-1; break;
            case 2: this.month = 14; this.year = year-1; break;
            default : this.month=month; this.year = year; break;
        }
    }
    
    enum Day {
        SATURDAY("Saturday"),
        SUNDAY("Sunday"),
        MONDAY("Monday"),
        TUESDAY("Tuesday"),
        WEDNESDAY("Wednesday"),
        THURSDAY("Thursday"),
        FRIDAY("Friday");     
        
        private final String dayOfWeek;
        Day(String dayOfWeek){
            this.dayOfWeek = dayOfWeek;
            }
            @Override
        public String toString(){
            return this.dayOfWeek;
            }  
        }
    
    public Day getDayOfWeek(){
        int q = this.dayOfMonth;
        int m = this.month;
        int j = this.year/100;
        int k = this.year%100;
        int h = (q+((26*(m+1))/10)+k+(k/4)+(j/4)+(5*j))%7;
        Day theDay;
        switch(h){
            case 0: theDay = Day.SATURDAY; break;
            case 1: theDay = Day.SUNDAY; break;
            case 2: theDay = Day.MONDAY; break;
            case 3: theDay = Day.TUESDAY; break;
            case 4: theDay = Day.WEDNESDAY; break;
            case 5: theDay = Day.THURSDAY; break;
            case 6: theDay = Day.FRIDAY; break;
            default : theDay = null; break;
        }
        return theDay;
    }
}    
