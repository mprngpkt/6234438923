package lab6_3;

public class CityGridTester {
    public static void main(String[] args) {
        CityGrid steppy = new CityGrid(10,10);
        int count = 0;
        int maxstep = 0;
        double total = 0;
        for(int i=1; i<10001; i++){
            while (steppy.isInCity() && count < 1000) { 
                steppy.walk();
                count++;
            }
            total = total + count;
            if (maxstep < count) { maxstep = count; }
            count = 0;
            steppy.reset();    
        }
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n", total/10000);
        System.out.println("Maximum number of steps that a person can take and is still in the city: " + maxstep);
    }       
}