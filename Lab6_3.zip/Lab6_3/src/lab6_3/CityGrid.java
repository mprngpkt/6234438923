package lab6_3;

import java.util.Random;

public class CityGrid {

    private int xCoor,yCoor,gridSize,x,y;

    public CityGrid(int xx,int yy){
        x = xx;
        y = yy;
        gridSize = x*y;
        xCoor = x/2;
        yCoor = y/2;
    }
    
    public void walk(){
        Random in = new Random();
        int direction = in.nextInt(4);
        switch(direction){
            case 0: yCoor--;break;
            case 1: yCoor++;break;
            case 2: xCoor--;break;
            case 3: xCoor++;break;
        }
    }
    
    public boolean isInCity(){
        if ( yCoor>0 || yCoor<y || xCoor>0 || xCoor<x ){
            return true;
        }
        else { 
            return false;
        }
    }
    
    public void reset(){
        xCoor = gridSize/2;
        yCoor = gridSize/2;
        }
}