/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author usci
 */
public class CashRegisterTester {
    public static void main(String[] args) {
        CashRegister test = new CashRegister(7);
        test.recordPurchase(50);
        test.recordPurchase(10);
        test.recordTaxablePurchase(20);
        test.enterPayment(100);
        System.out.println("Your change is "+test.giveChange());
    }
}
