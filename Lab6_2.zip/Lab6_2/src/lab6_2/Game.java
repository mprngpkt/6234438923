package lab6_2;

import java.util.Random;
import java.util.Scanner;

public class Game {

    private int com;
    private int userScore;
    private int comScore;
    
    public void play(){
        while(userScore-comScore!=2 && comScore-userScore!=2){
            Scanner in = new Scanner(System.in);
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            String user = in.next();
//            if ( user == "0" && user == "1" && user == "2" ) {
//                Scanner again = new Scanner(System.in);
//                System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
//                user = again.next();
                switch(user){
                    case "0": System.out.println("You enter: ROCK");break;
                    case "1": System.out.println("You enter: PAPER");break;
                    case "2": System.out.println("You enter: SCISSOR");break;  
                    default: continue;
                }
            Random comTurn = new Random();
            com = comTurn.nextInt(3);
            switch(com){
                case 0: System.out.println("Computer enter: ROCK");break;
                case 1: System.out.println("Computer enter: PAPER");break;
                case 2: System.out.println("Computer enter: SCISSOR");break;        
            }
            if (user=="0")switch(com){
                case 0: System.out.println("It's a tie.");break;
                case 1: System.out.println("You lose!");comScore++;break;
                case 2: System.out.println("You win!");userScore++;break;
            }
            else if (user=="1")switch(com){
                case 0: System.out.println("You win!");userScore++;break;
                case 1: System.out.println("It's a tie.");break;
                case 2: System.out.println("You lose!");comScore++;break;
            }
            else switch(com){
                case 0: System.out.println("You lose!");comScore++;break;
                case 1: System.out.println("You win!");userScore++;break;
                case 2: System.out.println("It's a tie.");break;
            }  
        }
        if (userScore>comScore){
            System.out.println("----------------------------------------");
            System.out.println("Congrats! You win.");
            System.out.println("User Score: "+userScore);
            System.out.println("Computer Score: "+comScore);
        }
        else {
            System.out.println("----------------------------------------");
            System.out.println("Too bad! You lose.");
            System.out.println("User Score: "+userScore);
            System.out.println("Computer Score: "+comScore);
        }
    }
}