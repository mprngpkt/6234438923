package lab10_1;

public class Subject implements Evalution{
    
    private String subjName;
    private int[] score;
    
    public Subject(String subject_name, int[] scoreSj){
        subjName = subject_name;
        score = scoreSj;
    }
    
    @Override
    public double evaluate(){
        int total=0;
        for(int i=0; i<score.length; i++){
            total+=score[i];
        }
        double average = total/score.length;
        return average;
    }
    
    @Override
    public char grade(double g){
        g = evaluate();
        if(g>=70){
            return 'P';
        }
        else{
            return 'F';
        }
    }
    
    @Override
    public String toString(){
        return subjName;
    }
    
}