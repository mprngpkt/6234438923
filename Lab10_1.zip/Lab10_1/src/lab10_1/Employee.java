package lab10_1;

public class Employee {
    
    private String name;
    int salary;
    
    public Employee(String name ,int salary){
        this.name = name;
        this.salary = salary;
    }
    
    public void setSalary(int s){
        salary=s;
    }
    
    @Override
    public String toString(){
        return (name+"\n"+"Salary = "+salary);
    }
}
