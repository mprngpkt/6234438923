/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_1;

/**
 *
 * @author usci
 */
public class InsectPopulation {
    private double total;
    public InsectPopulation(double number){
        total = number;
    }
    public void breed(){
        total = total*2;
    }
    public void spray(){
        total = total*0.9;
    }
    public double getNumInsect(){
        return total;
    }

    
}
