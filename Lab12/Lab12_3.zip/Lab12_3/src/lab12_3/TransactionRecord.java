package lab12_3;

public class TransactionRecord {
    
    private int acctNo;
    private int transCnt;
    private double balance;
    
    public TransactionRecord(int acctNo, double balance){
        this.acctNo = acctNo;
        this.transCnt = 1;
        this.balance = balance;
    }
    
    public int getAcctNo() { return acctNo; }

    public void setAcctNo(int a) {
        this.acctNo = a;
    }

    public int getTransCnt() { return transCnt; }

    public void setTransCnt(int transCnt) {
        this.transCnt = transCnt;
    }
    
    public double getBalance() { return balance; }

    public void setBalance(double b) {
        this.balance = b;
    }

//    @Override
//    public String toString() {
//        return "acctNo." + acctNo + ", balance = " + balance + ", transCnt = " + transCnt;
//    }
    
}
