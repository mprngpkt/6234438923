package lab12_1;

import java.io.*;
import java.util.Scanner;

public class HiJohn {

    public static void main(String[] args) throws FileNotFoundException{
        
        File file = new File("text.txt");
        Scanner in = new Scanner(System.in);
        PrintWriter writer = new PrintWriter(file);
        String line = in.nextLine();
        while(!line.equals("quit")){
            writer.println(line);
            line = in.nextLine();
        }
        writer.close();
        
        Scanner reader = new Scanner(file);
        int chars=0;
        int words=0;
        int lines=0;
        while(reader.hasNextLine()){
            String read = reader.nextLine();
            lines++;
            String[] word_list = read.split(" ");
            words += word_list.length;
            chars += read.length();
        }
        System.out.println("Total characters : "+chars);
        System.out.println("Total words : "+words);
        System.out.println("Total lines : "+lines);
    }
    
}
