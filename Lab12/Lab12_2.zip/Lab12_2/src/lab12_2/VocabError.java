package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class VocabError {

    public static void main(String[] args) {
        
        File file = new File("wordlist.txt");
        Scanner read = null;
        ArrayList<String> word_list = new ArrayList<>();     
        try {
            read = new Scanner(file);
            while (read.hasNextLine()) {
                String line = read.nextLine();
                word_list.add(line);
            }
        }
        catch (FileNotFoundException e) { e.printStackTrace(); }
        finally {
            if (read != null) {
                read.close();
            }
        }

        Scanner sentence = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String input = sentence.nextLine();
        
        String words_error = "";
        boolean words_contain = true;
        String[] words = input.split(" ");
        for (String word : words) {
            if (!word_list.contains(word)) {
                words_contain = false;
                words_error += word;
                words_error += " ";
            }
        }

        System.out.println("Words not contained:");
        if (words_contain) {
            System.out.println("N/A");
        }
        else {
            System.out.println(words_error);
        }
        
        
    }
    
}
