/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author usci
 */
public class Letter {
    private String sender;
    private String reciever;
    private String paragraph;
    public Letter(String from, String to){
        sender = from;
        reciever = to;
        paragraph = "";
    }
    public void addLine(String line){
        paragraph = paragraph+"\n"+line;
    }
    public String getText(){
        return ("Dear "+sender+":\n"+paragraph+"\n"+"\n"+"Sincerely,"+"\n"+"\n"+reciever);
    }
   
}
