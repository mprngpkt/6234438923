package lab8_1;

public class Truck extends Car {
    private final double M_weight; 
    private double weight;
    
    public Truck(double gas, double efficiency, double M_weight, double weight){
        super(gas, efficiency);
        this.M_weight = M_weight;
        this.weight = weight;
        if (this.weight > this.M_weight){
            weight = M_weight;
        }
    }
    @Override public void drive(double distance){
        double waste;
        if (weight>20){
            waste = (distance/super.getEfficiency())*1.30;
        }
        else if (weight>10){
            waste = (distance/super.getEfficiency())*1.20;
        }
        else if (weight>=1){
            waste = (distance/super.getEfficiency())*1.10;
        }
        else{
            waste = distance/super.getEfficiency();
        }
        
        if (waste > super.getGas()){
            System.out.println("You cannot drive too far, please add gas");
        }
        else{
            double gas = super.getGas()-waste;
            super.setGas(gas);
        }
   
    }
}