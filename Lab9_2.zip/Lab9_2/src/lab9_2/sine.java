package lab9_2;

public class sine extends Taylor{
    
    public sine(int k, double x){
        super(k,x);
    }
    
    @Override
    public double getApprox(){
        double approx = 0;
        for(int n=0; n<=super.getIter(); n++){
            approx += ((Math.pow(-1,n))*(Math.pow(super.getValue(), 2*n+1)))/super.factorial(2*n+1);
        }
        return approx;
    }
    
    @Override
    public void printValue(){
        System.out.println("Value from Math.sin() is "+ Math.sin(super.getValue()));
        System.out.println("Approximated value is "+getApprox());
    }
    
}
