package lab9_2;

public class expo extends Taylor{
    
    public expo(int k, double x){
        super(k,x);
    }
    
    @Override
    public double getApprox(){
        double approx = 0;
        for(int n=0; n<=super.getIter(); n++){
            approx += Math.pow(super.getValue(), n)/super.factorial(n);
        }
        return approx;
    }
    
    @Override
    public void printValue(){
        System.out.println("Value from Math.exp() is "+Math.exp(super.getValue()));
        System.out.println("Approximated value is "+getApprox());
    }
}