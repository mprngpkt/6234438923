package lab9_1;

import java.util.ArrayList;

public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
    
    public Order(Customer c){
        cntOrder++;
        this.id = cntOrder;
        this.c = c;
        this.p = new ArrayList<Pizza>();
    }
    
    public void addPizza(Pizza pizza){
        p.add(pizza);
    }
    
    public String getOrderDetail(){
        //ข้อมูลลูกค้า ข้อมูล pizza ที่สั่ง จำนวนถาดที่สั่งและราคารวม
        String detail = "Order id : "+id+"\n"+c.getNameCustm()+" tel : "+c.getTel();
        
        if (c instanceof GoldCustomer) {
            GoldCustomer newGold = (GoldCustomer) c;
            detail+= " discount : "+ newGold.getDiscount();
        }
        detail+="\n";

        for(Pizza pizza : p){
            detail+= pizza.getMenu()+" price : "+ pizza.getPrice();
            if (pizza instanceof PizzaSpecial){
                detail+= " special : "+((PizzaSpecial) pizza).getSpecial();
            }
            detail+="\n";
        }
        
        detail+= "Total pieces : "+p.size()+"\n"+"Total cost : "+calculatePayment();
        return detail;
    }
    
    public double calculatePayment(){
        double total = 0;
        for(Pizza pizza : p){
            total = total + pizza.getPrice();
        }
        if(c instanceof GoldCustomer){
            GoldCustomer newGold = (GoldCustomer) c;
            total = total*((100-newGold.getDiscount())/100);
        }
        return total;
    }
    
}