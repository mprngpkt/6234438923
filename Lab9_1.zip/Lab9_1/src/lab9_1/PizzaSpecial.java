package lab9_1;

public class PizzaSpecial extends Pizza{
    private String special;
    
     public PizzaSpecial(String name, double price, String special){
        super(name, price);
        this.special = special;
    }
    @Override
    public String getMenu(){
        return super.getMenu();
    }
    
    @Override
    public double getPrice(){
        return super.getPrice();
    }
    
    public String getSpecial(){
        return special;
    }
    
    @Override
    public String toString() {
        return super.toString() + "Special : " + getSpecial();
    }
}