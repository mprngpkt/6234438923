package lab9_1;

public class GoldCustomer extends Customer{
    private double discount;
    
    public GoldCustomer(String name, String tel, double discount){
        super(name, tel);
        this.discount = discount;
    }
    
    @Override
    public String getNameCustm(){
        return super.getNameCustm();
    }
    
    @Override
    public String getTel(){
        return super.getTel();
    }
    
    public double getDiscount(){
        return discount;
    }
    
    @Override
    public String toString() {
        return super.toString() + "Discount% : " + getDiscount();
    }
}
