package lab7_2;

public class MagicSquareTester {
    public static void main(String[] args) {
        MagicSquare box = new MagicSquare(5);
        System.out.println(box.toString());
    }
}