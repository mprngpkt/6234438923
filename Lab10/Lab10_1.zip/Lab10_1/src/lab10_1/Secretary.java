package lab10_1;

public class Secretary extends Employee implements Evalution{
    
    private int typingSpeed;
    private int[] score;
    
    public Secretary(String name ,int salary ,int[] sc ,int ts){
        super(name,salary);
        score = sc;
        typingSpeed = ts;
    }
    
    @Override
    public double evaluate(){
        int total=0;
        for(int i=0; i<score.length; i++){
            total+=score[i];
        }
        return total;
    }
    
    public char grade(double g){
        g = evaluate();
        if(g>=90){
            setSalary(18000);
            return 'P';
        }
        else{
            return 'F';
        }
    }
    
    
    
}
